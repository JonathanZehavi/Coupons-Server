package com.john.coupons.enums;

public enum Role {
    Customer,
    Company,
    Admin
}


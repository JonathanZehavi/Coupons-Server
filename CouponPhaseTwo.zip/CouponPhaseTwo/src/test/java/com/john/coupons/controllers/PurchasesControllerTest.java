package com.john.coupons.controllers;

import junit.framework.TestCase;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class PurchasesControllerTest {

    public void testCreatePurchase() {
    }

    public void testUpdatePurchase() {
    }

    public void testGetPurchaseById() {
    }

    public void testDeletePurchase() {
    }


    public void testGetAllPurchases() {
    }

}